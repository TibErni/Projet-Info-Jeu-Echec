#include "header.h"

void initialize_board(Board board, Piece player1_promoted, Piece player2_promoted);
int get_color_index(int x, int y);
void print_board(const Board board);